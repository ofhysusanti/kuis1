package com.example.reclyclerview;

import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.lang.reflect.Type;
import java.util.ArrayList;

class keluargaAdapter extends RecyclerView.Adapter<keluargaAdapter.keluargaViewHolder> {
    private ArrayList<keluarga>dataList;

    public keluargaAdapter(ArrayList<keluarga> keluargaArrayList) {
        this.dataList = dataList;
    }

    @NonNull
    @Override

    public keluargaAdapter.keluargaViewHolder.onCreateViewHolder(@)NonNull ViewGroup parent, int view Type);

    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public class keluargaViewHolder {
    }
}
